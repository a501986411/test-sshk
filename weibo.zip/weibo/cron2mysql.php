<?php
/**
 * 同步用户微博至MySQL
 * User: chl
 * Date: 2018/5/9
 * Time: 15:50
 */

include_once  __DIR__.'/lib.php';
$pdo = new PDO("mysql:host=192.168.5.37;dbname=dba",'dba','Chen19920328!@#');
$r = connredis();
$sql = "insert into post (postid,userid,time,content) values ";
$i = 0;
while($r->lLen('global:store') && $i++ < 1000){
    $postid = $r->rPop('global:store');
    $post = $r->hMGet('post:postid:'.$postid,['userid','time','content']);
    $sql .= "(".$postid.",".$post['userid'].",".$post['time'].",'".$post['content']."'),";
}
if($i < 1){
    echo 'no job';
    exit;
}
$sql = rtrim($sql,',');
$result = $pdo->exec($sql);

if($result){
    $pdo->lastInsertId();
}
echo $pdo->errorInfo();
print_r($result);

?>

