<?php include_once './lib.php';?>
<?php include_once './header.php';?>
<?php
    $userInfo = islogin();
    if($userInfo === false){
        header('location:index.php');
        exit;
    }

    //取出自己和粉主推送的微博
    $r = connredis();
//    $r->lTrim('recivepost:'.$userInfo['userid'],0,49);
//    //$newpost = $r->sort('recivepost:'.$userInfo['userid'],array('sort'=>'desc','get'=>'post:postid:*:content'));


    //获取我关注的人
    $star = $r->sMembers('following:'.$userInfo['userid']);
    $star[] = $userInfo['userid'];
    $lastpull = $r->get('lastpull:userid:'.$userInfo['userid']);
    $maxpostid = $r->get('global:postid'); //微博最大id
    if(!$lastpull){
        $lastpull = 0;
    }
    //拉取微博最新数据
    $latest = [];
    foreach ($star as $s){
        $latest = array_merge($latest,$r->zRangeByScore('starpost:userid:'.$s,$lastpull+1,$maxpostid));
    }
    sort($latest,SORT_NUMERIC);
    //最新微博插入list结构
    foreach ($latest as $newpostid){
        $r->lPush('recivepost:'.$userInfo['userid'],$newpostid);
    }
    //保持个人主页，至多收入1000条微博
    $r->lTrim('recivepost:'.$userInfo['userid'],0,999);
    //跟新lastpull
    if(!empty($latest)){
        $r->set('lastpull:userid:'.$userInfo['userid'],end($latest));
    }
    $newpost = $r->sort('recivepost:'.$userInfo['userid'],array('sort'=>'desc'));
    $fansnum = $r->sCard('follower:'.$userInfo['userid']); //粉丝数量
    $fansingnum = $r->sCard('following:'.$userInfo['userid']); //关注数量
?>


<div id="navbar">
<a href="index.php">主页</a>
| <a href="timeline.php">热点</a>
| <a href="logout.php">退出</a>
</div>
</div>
<div id="postform">
<form method="get" action="post.php">
<?php echo $userInfo['username'];?>, 有啥感想?
<br>
<table>
<tr><td><textarea cols="70" rows="3" name="status"></textarea></td></tr>
<tr><td align="right"><input type="submit" name="doit" value="Update"></td></tr>
</table>
</form>
<div id="homeinfobox">
<?php echo $fansnum;?> 粉丝<br>
<?php echo $fansingnum;?> 关注<br>
</div>
</div>

<?php
foreach($newpost as $postid):
    $post = $r->hMGet('post:postid:'.$postid,['userid','time','content']);
    $username = $r->get('user:userid:'.$post['userid'].':username');
?>
<div class="post">
<a class="username" href="profile.php?u=<?php echo $username;?>"><?php echo $username;?></a> <?php echo $post['content'];?><br>
<i><?php echo formatetime($post['time']);?> 前 通过 web发布</i>
</div>
<?php endforeach;?>


<?php include_once './footer.php';?>
