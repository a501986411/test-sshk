<?php
/**
 * Created by PhpStorm.
 * User: chl
 * Date: 2018/5/3
 * Time: 17:40
 */
require_once './lib.php';
$r = connredis();
$r->del('user:userid:'.$_COOKIE['userid'].':username:'.$_COOKIE['username'].':authsecret');
setcookie('username','',-1);
setcookie('userid','',-1);
setcookie('authsecret','',-1);


header('location:index.php');