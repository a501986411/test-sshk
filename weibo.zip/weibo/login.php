<?php
    /**
     * 登陆页面
     *
     * 步骤：
     * 1.接收数据，判断数据完整性
     * 2.查询用户名是否存在
     * 3.查询密码是否匹配
     * 4.设置cookie
     */
    include_once './lib.php';
    include_once './header.php';

    if(islogin() != false){
        header('location:home.php');
        exit;
    }
    $username = P('username');
    $password = P('password');
    if(!$username||!$password){
        error('请输入完整登陆信息');
    }
    $r = connredis();
    $useid = $r->get('user:username:'.$username.':userid');
    if(!$useid){
        error('用户名不存在');
    }

    $realpass = $r->get('user:userid:'.$useid.':password');
    if($password !== $realpass){
        error('输入的密码不正确');
    }
    $authsecret = randsecret();
    $r->set('user:userid:'.$useid.':username:'.$username.':authsecret',$authsecret);
    //设置cookie登陆成功
    setcookie('username',$username);
    setcookie('userid',$useid);
    setcookie('authsecret',$authsecret);
    header('location:home.php');

