<?php
/**
 * Created by PhpStorm.
 * User: chl
 * Date: 2018/5/3
 * Time: 17:02
 * 设计post表的key规则
    发微博：
    incr global:postid   //自增长postid
    set post:postid:3:time $time
    set post:postid:3:userid $userid
    set post:postid:3:content $content

 * 步骤：
 * 1.判断是否登陆
 * 2.接收数据
 * 3.set redis
 */
include_once  __DIR__.'/lib.php';


include_once  __DIR__.'/header.php';

$user = islogin();
if($user === false){
    header('location:index.php');
    exit;
}
$content = G('status');
if(!$content){
    error('数据不完整，请重新输入');
}
$r = connredis();
$postid = $r->incr('global:postid');
//$r->set('post:postid:'.$postid.':userid',$user['userid']);
//$r->set('post:postid:'.$postid.':time',time());
//$r->set('post:postid:'.$postid.':content',$content);
//hash存储
$r->hmset ('post:postid:'.$postid,['userid'=>$user['userid'],'time'=>time(),'content'=>$content]);




//设计1：把微博推送给粉丝
//$fans = $r->sMembers('follower:'.$user['userid']);
//$fans[] = $user['userid'];
//foreach($fans as $fansid){
//    $r->lPush('recivepost:'.$fansid,$postid);
//}

//设计2：把自己发的微博维护在有序集合里，只维护前20个
$r->zAdd('starpost:userid:'.$user['userid'],$postid,$postid);

if($r->zCard('starpost:userid:'.$user['userid'])>20){
    $r->zRemRangeByRank('starpost:userid:'.$user['userid'],0,0);
}

//维护用户1000个最新微博 供自己查看，把自己的微博id发到链表 ，用于自己看自己的微博
//1000个之前的旧微博放入mysql

$r->lPush('mypost:userid:'.$user['userid'],$postid);
if($r->lLen('mypost:userid:'.$user['userid']) > 1000){
    $r->rpoplpush('mypost:userid:'.$user['userid'],'global:store');
}
header('location:home.php');
exit();
include_once  './footer.php';
