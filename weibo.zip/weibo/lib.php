<?php
/**
 * 基础函数库
 * User: chl
 * Date: 2018/5/3
 * Time: 15:51
 */

/**
 * 获取post数据
 * @param $key
 * @return mixed
 */
Error_reporting(E_ALL & ~E_NOTICE);

function P($key){
    return $_POST[$key];
}
/**
 * 获取post数据
 * @param $key
 * @return mixed
 */
function G($key){
    return $_GET[$key];
}

/**
 * 报错函数
 * @param $msg
 */
function error($msg){
    echo "<div>";
    echo $msg;
    echo "</div>";
    include('./footer.php');
    exit;
}

/**
 * 链接redis
 * @return null|Redis
 */
function connredis(){
    static $r = null;
    if($r !== null){
        return $r;
    }
    $r = new Redis();
    $r->connect('192.168.5.37',6379);
    return $r;
}

/**
 * 判断用户是否登陆
 */
function islogin(){
    if(!$_COOKIE['userid'] || !$_COOKIE['username']){
        return false;
    }
    if(!$_COOKIE['authsecret']){
        return false;
    }
    $r = connredis();
    $authsecret = $r->get('user:userid:'.$_COOKIE['userid'].':username:'.$_COOKIE['username'].':authsecret');
    if($authsecret !== $_COOKIE['authsecret']){
        return false;
    }
    return ['userid'=>$_COOKIE['userid'],'username'=>$_COOKIE['username']];
}

//产生随机字符串
function randsecret(){
    $str = 'abcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()';
    return substr(str_shuffle($str),0,16);
}

function formatetime($time){
    $sec = time()-$time;
    if($sec >= 86400){
        return floor($sec/86400).'天';
    }else if($sec >= 3600){
        return floor($sec/3600).'小时';
    }else if($sec >= 60){
        return floor($sec/60).'分钟';
    }else if($sec >=0 ){
        return $sec.'秒';
    }



}