<?php
/**
 * Created by PhpStorm.
 * User: chl
* Date: 2018/5/3
* Time: 18:14
*/
include_once './lib.php';
include_once './header.php';
if(($user = islogin()) === false){
    header('location:index.php');
    exit;
}

/**
 * 关注思路：
 *  每人有自己的粉丝记录 set
 *  每人有自己的关注记录 set
 *  aid 关注 bid
 *  发生
 *  following:aid (bid)
 *  follower:bid (aid)
 *
 */
$uid = G('uid'); //关注或者取消关注的的用户id
$f = G('f');//关注或者取消关注
/**
 * TODO:判断uid，f是否合法,uid不能是自己
 */
if(!$uid || !in_array($f,[0,1])){
    error('参数不合法');
}
if($uid == $user['userid']){
    error('不能关注自己');
}

$r = connredis();
$uname = $r->get('user:userid:'.$uid.':username');
if($f){ // 关注
    $r->sAdd('following:'.$user['userid'],$uid);
    $r->sAdd('follower:'.$uid,$user['userid']);
}else{//取消关注
    $r->sRem('following:'.$user['userid'],$uid);
    $r->sRem('follower:'.$uid,$user['userid']);
}
header('location:profile.php?u='.$uname);
exit;





include_once './footer.php';
