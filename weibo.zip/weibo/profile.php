<?php
include_once './lib.php';
include_once './header.php';
if(($user = islogin()) === false){
    header('location:index.php');
    exit;
}
/**
 * 关注：
 *  每人有自己的粉丝记录 set
 *  每人有自己的关注记录 set
 *  aid 关注 bid
 *  发生
 *  following:aid (bid)
 *  follower:bid (aid)
 *
 */

/**
 * 步骤：
 * 1.获取用户名
 * 2.查询用户id
 * 3.判断userid 是否在following 集合里
 */

$u = G('u');
$r = connredis();
$prouid = $r->get('user:username:'.$u.':userid');
if(!$prouid){
    error('非法用户');
}
$isf = $r->sIsMember('following:'.$user['userid'],$prouid);
$isdof = $isf ? 0 : 1;
$isword = $isf ? '取消关注' : '关注他';

?>
<div id="navbar">
<a href="index.php">主页</a>
| <a href="timeline.php">热点</a>
| <a href="logout.php">退出</a>
</div>
</div>
<h2 class="username"><?php echo $u;?></h2>
<a href="follow.php?uid=<?php echo $prouid;?>&f=<?php echo $isdof;?>" class="button"><?php echo $isword;?> </a>

<div class="post">
<a class="username" href="profile.php?u=test">test</a> 
world<br>
<i>11 分钟前 通过 web发布</i>
</div>

<div class="post">
<a class="username" href="profile.php?u=test">test</a>
hello<br>
<i>22 分钟前 通过 web发布</i>
</div>

<?php
include_once './footer.php';
?>
