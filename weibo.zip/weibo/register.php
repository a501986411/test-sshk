<?php
/**
 * 注册功能
 * User: chl
 * Date: 2018/5/3
 * Time: 15:42
 */

/**
 *  设计user表对应的key规则
    注册用户
    set user:userid:1:username zhangsan
    set user:userid:1:password 1111111
    ##冗余数据
    set user:username:zhangsan:userid 1
 *
 * 生成user：
 *  incr global:userId
 *
 *
 * 步骤:
 *  1.接收POST数据，判断数据合法性
 *  2.链接redis，查询该用户名是否存在
 *  3.数据写入redis
 *  4.完成登录操作
 */
include_once  './lib.php';
include_once './header.php';

if(islogin() != false){
    header('location:home.php');
    exit;
}

$username = P('username');
$password = P('password');
$password2 = P('password2');
if(!$username || !$password ||!$password2){
    error('请输入完整注册信息');
}
//判断密码是否一致
if($password !== $password2){
    error('两次密码输入不一致');
}
//链接redis
$r = connredis();
//查询用户名是否已被注册
$userid = $r->get('user:username:'.$username.':userid');
if($userid){
    error('用户名已被注册');
}
//获取userid
$userid = $r->incr('global:userid');
//注册数据保存
$r->set('user:userid:'.$userid.":username",$username);
$r->set('user:userid:'.$userid.":password",$password);
//冗余数据处理
$r->set('user:username:'.$username.":userid",$userid);
//同过链表威武50个最新的userid
$r->lpush('newuserlink',$userid);
//每次截取前50个
$r->ltrim('newuserlink',0,49);

include_once './footer.php';




